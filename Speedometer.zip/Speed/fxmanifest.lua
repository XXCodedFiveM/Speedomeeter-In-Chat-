fx_version 'cerulean'
game {'gta'}


client_scripts {
    'cl_speed.lua'
}